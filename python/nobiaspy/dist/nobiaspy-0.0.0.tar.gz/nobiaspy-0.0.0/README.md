#nobiaspy - youtube fallacy and fact checker
Be patient with it, i am using gemini api so it might take a while.


It works by adding the youtube id or url and language code e.g en, sv, es, fr and etc.
Then it complies a list of fallacies it finds in said youtube transcript and fact checks it using google search api.

Finally it compiles a summary of the youtube videos and explains every fallacy found and a quick fact check.

how to use: 
    
    1. pip install nobiaspy --break-system-packages

    2. nobiaspy --help 

just run ``` nobiaspy --help ``` and it tells you what to do.

bye and hope you don't get fooled by youtube videos.

disclaimer: AI isn't perfect and can still make mistakes.